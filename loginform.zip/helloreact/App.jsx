import React from 'react';
import ReactDOM from 'react-dom';

class App extends React.Component 
{
  constructor(props)
  {
    super(props);
    this.state = {value: ''};
	this.state = {value1: ''};

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event)
  {
    this.setState({value: event.target.value});
	//this.setState({value1: event.target.value1});
  }
  
  handleChange1(event)
  {
   	this.setState({value: event.target.value1});
  }

  handleSubmit(event)
  {
    alert('name and password are submitted ' + this.state.value);
    event.preventDefault();
	
	
  }

  render() 
  {
    return (
      <form onSubmit={this.handleSubmit}>
        <label>
          Username: 
          <input type="text" value={this.state.value} onChange={this.handleChange} />
        </label>
        <br/>

         <label>
          Password:      
          <input type="password" value={this.state.value1} onChange={this.handleChange1} />
        </label>
        <br/>
      <br/>
        <input type="submit" value="Submit" />
		<input type="cancel" value="cancel" />
      </form>
    );
  }
}


export default App;

