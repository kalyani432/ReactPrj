Directory for ui code written in reactjs
