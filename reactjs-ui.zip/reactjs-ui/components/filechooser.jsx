import React from 'react';

class FileChooser extends React.Component{
	render(){
		return (
		
			<div>
				<input type	 = "file" name="file1"/> <br/>
			</div>
		);
	}
}
export default FileChooser;
