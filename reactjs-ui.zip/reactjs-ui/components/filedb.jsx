import React from 'react';

class FileDB extends React.Component{
	    render(){
			console.log("1");
			return (
			<div>
		<h1>{this.props.name}</h1>

			</div>
			);
		}
}
export default FileDB;
