 var data = 
         [ {
            name: 'England ',
            /*link: 'http://localhost:8082/',*/
            sub: [{
                name: 'Arsenal',
                link: '0-0',
                sub: null
            }, {
                name: 'Liverpool',
                link: '0-1',
                sub: null
            }, {
                name: 'Manchester',
                link: '0-2',
                sub: null
            }]
        }]
    