import React from 'react';
import ReactDOM from 'react-dom';

class App extends React.Component 
{
  constructor(props)
  {
    super(props);
    this.state = 
	{
		value: '',
		value1: ''
	 };
    this.handleChange = this.handleChange.bind(this);
	this.handleChange1 = this.handleChange1.bind(this);
	this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event)
  {
    this.setState({value: event.target.value.substr(0,8)});
	
	//this.setState({role: this.state.value});
	//this.setState({value1: event.target.value1.substr(0,8)});
  }
  
  handleChange1(event)
  {
   	this.setState({value1: event.target.value.substr(0,20)});
  }

  handleSubmit(event)
  {
	  console.log(this.state.value);
	  //this.setState.role=this.state.value;
	 // alert(role);
	const role=this.state.value;
	console.log(value);
	 
	 if (role =='admin')
	 {
			<div>
		AdminLogin=	 <AdminLogin/>
		</div>
	}
		 // alert('name submitted ' + role);
	else if(role == 'operator')
	{
		OpertLogin = <OpertLogin/>; 
	}
	else if(role =='lead')
	{ 
		LeadLogin = <LeadLogin/>;  
	}
	else
	{ 
	alert('error' + this.state.value); 
	}
     
	 //alert('name and password are submitted ' + this.state.value);
  //  event.preventDefault();
  }
  
 
  render() 
  {
    return (
      <form onSubmit={this.handleSubmit}>
        <label>
          Username: 
          <input id='user' type="text" value={this.state.value} onChange={this.handleChange} />
        </label>
        <br/>

         <label>
          Password:      
          <input type="password" value={this.state.value1} onChange={this.handleChange1} />
        </label>
        <br/>
      <br/>
  <input type="submit" value="Submit"/>
		<input type="button" value="cancel" />
      </form>
	
    );
  }
}


class AdminLogin extends React.Component 
{
   render() {
      return (
         <div>
            <h1>
			AdminLogin
			</h1>
         </div>
      );
   }
}


class OpertLogin extends React.Component 
{
   render() {
      return (
         <div>
            <h1>OperatorLogin</h1>
         </div>
      );
   }
}


class LeadLogin extends React.Component 
{
   render() {
      return (
         <div>
            <h1>LeadLogin</h1>
         </div>
      );
   }
}


export default App;

